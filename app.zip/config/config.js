const config = {};

config.database = {};

export { config };
