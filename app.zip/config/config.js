const config = {};

config.database = {};

console.log(config.database);

export { config };
